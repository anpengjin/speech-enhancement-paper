The format of the file name is "uttid1-angle1-uttid2-angle2-rt60-sir-snr.wav":
"uttid" and "angle" respectively represent the voice name and its angle relative to the array, and "rt" is the reverberation time(rt60).
"sir" is the signal-to-noise ratio between the target speaker and the interfering speaker.
"snr" is the signal-to-noise ratio between the target speaker and the background noise.

The source file is 5-channel audio, in which the first four channels are array observation signals, and the last channel is the target speech signal with reverberation.
